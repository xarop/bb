# Block Spacer

Reduces or extends the vertical space between components.
