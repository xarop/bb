# Feature Flexible Content Extension

Extends Flexible Content by adding component preview in the “Add Component” menu and next to the title of a component that was added to the page. It also adds component search in the tooltip to easily find the component by name.
