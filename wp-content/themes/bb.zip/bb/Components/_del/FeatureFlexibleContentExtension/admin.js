import.meta.glob('./scripts/*.js', { eager: true })
