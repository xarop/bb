# List Search Results

Uses the standard WordPress search functionality. Shows a a search input on top of the paginated results list.
