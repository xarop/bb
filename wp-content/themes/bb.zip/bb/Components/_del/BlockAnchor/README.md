# Block Anchor

Drop Block Anchor anywhere in the page and create an anchor link from unique name. Copy and use anchor link to scroll to this position.
