# Reusable Component

The reusable component allows you to save a component or group of components which you can later use in any post or page on your site. If you are often adding the same content to the same component or group of components, using the reusable component will save you a great chunk of time.
